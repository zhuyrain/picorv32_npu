-- Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2018.3 (win64) Build 2405991 Thu Dec  6 23:38:27 MST 2018
-- Date        : Tue Jul  7 16:05:02 2026
-- Host        : 8845HS running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode synth_stub
--               D:/Projects/Verilog/Vivado/project_riscv_npu/project_riscv_npu.srcs/sources_1/bd/design_1/ip/design_1_tb_picorv32_0_0/design_1_tb_picorv32_0_0_stub.vhdl
-- Design      : design_1_tb_picorv32_0_0
-- Purpose     : Stub declaration of top-level module interface
-- Device      : xc7a35tfgg484-2
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity design_1_tb_picorv32_0_0 is
  Port ( 
    clk : in STD_LOGIC;
    resetn : in STD_LOGIC;
    interconnect_aresetn : in STD_LOGIC;
    uart_axi_awaddr : out STD_LOGIC_VECTOR ( 31 downto 0 );
    uart_axi_awvalid : out STD_LOGIC;
    uart_axi_awready : in STD_LOGIC;
    uart_axi_wdata : out STD_LOGIC_VECTOR ( 31 downto 0 );
    uart_axi_wstrb : out STD_LOGIC_VECTOR ( 3 downto 0 );
    uart_axi_wvalid : out STD_LOGIC;
    uart_axi_wready : in STD_LOGIC;
    uart_axi_bresp : in STD_LOGIC_VECTOR ( 1 downto 0 );
    uart_axi_bvalid : in STD_LOGIC;
    uart_axi_bready : out STD_LOGIC;
    uart_axi_araddr : out STD_LOGIC_VECTOR ( 31 downto 0 );
    uart_axi_arvalid : out STD_LOGIC;
    uart_axi_arready : in STD_LOGIC;
    uart_axi_rdata : in STD_LOGIC_VECTOR ( 31 downto 0 );
    uart_axi_rresp : in STD_LOGIC_VECTOR ( 1 downto 0 );
    uart_axi_rvalid : in STD_LOGIC;
    uart_axi_rready : out STD_LOGIC
  );

end design_1_tb_picorv32_0_0;

architecture stub of design_1_tb_picorv32_0_0 is
attribute syn_black_box : boolean;
attribute black_box_pad_pin : string;
attribute syn_black_box of stub : architecture is true;
attribute black_box_pad_pin of stub : architecture is "clk,resetn,interconnect_aresetn,uart_axi_awaddr[31:0],uart_axi_awvalid,uart_axi_awready,uart_axi_wdata[31:0],uart_axi_wstrb[3:0],uart_axi_wvalid,uart_axi_wready,uart_axi_bresp[1:0],uart_axi_bvalid,uart_axi_bready,uart_axi_araddr[31:0],uart_axi_arvalid,uart_axi_arready,uart_axi_rdata[31:0],uart_axi_rresp[1:0],uart_axi_rvalid,uart_axi_rready";
attribute X_CORE_INFO : string;
attribute X_CORE_INFO of stub : architecture is "tb_picorv32,Vivado 2018.3";
begin
end;
