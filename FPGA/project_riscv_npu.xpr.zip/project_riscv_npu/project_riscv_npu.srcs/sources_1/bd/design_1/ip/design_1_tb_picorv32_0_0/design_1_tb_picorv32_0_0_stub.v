// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2018.3 (win64) Build 2405991 Thu Dec  6 23:38:27 MST 2018
// Date        : Tue Jul  7 16:05:02 2026
// Host        : 8845HS running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               D:/Projects/Verilog/Vivado/project_riscv_npu/project_riscv_npu.srcs/sources_1/bd/design_1/ip/design_1_tb_picorv32_0_0/design_1_tb_picorv32_0_0_stub.v
// Design      : design_1_tb_picorv32_0_0
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7a35tfgg484-2
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* X_CORE_INFO = "tb_picorv32,Vivado 2018.3" *)
module design_1_tb_picorv32_0_0(clk, resetn, interconnect_aresetn, 
  uart_axi_awaddr, uart_axi_awvalid, uart_axi_awready, uart_axi_wdata, uart_axi_wstrb, 
  uart_axi_wvalid, uart_axi_wready, uart_axi_bresp, uart_axi_bvalid, uart_axi_bready, 
  uart_axi_araddr, uart_axi_arvalid, uart_axi_arready, uart_axi_rdata, uart_axi_rresp, 
  uart_axi_rvalid, uart_axi_rready)
/* synthesis syn_black_box black_box_pad_pin="clk,resetn,interconnect_aresetn,uart_axi_awaddr[31:0],uart_axi_awvalid,uart_axi_awready,uart_axi_wdata[31:0],uart_axi_wstrb[3:0],uart_axi_wvalid,uart_axi_wready,uart_axi_bresp[1:0],uart_axi_bvalid,uart_axi_bready,uart_axi_araddr[31:0],uart_axi_arvalid,uart_axi_arready,uart_axi_rdata[31:0],uart_axi_rresp[1:0],uart_axi_rvalid,uart_axi_rready" */;
  input clk;
  input resetn;
  input interconnect_aresetn;
  output [31:0]uart_axi_awaddr;
  output uart_axi_awvalid;
  input uart_axi_awready;
  output [31:0]uart_axi_wdata;
  output [3:0]uart_axi_wstrb;
  output uart_axi_wvalid;
  input uart_axi_wready;
  input [1:0]uart_axi_bresp;
  input uart_axi_bvalid;
  output uart_axi_bready;
  output [31:0]uart_axi_araddr;
  output uart_axi_arvalid;
  input uart_axi_arready;
  input [31:0]uart_axi_rdata;
  input [1:0]uart_axi_rresp;
  input uart_axi_rvalid;
  output uart_axi_rready;
endmodule
