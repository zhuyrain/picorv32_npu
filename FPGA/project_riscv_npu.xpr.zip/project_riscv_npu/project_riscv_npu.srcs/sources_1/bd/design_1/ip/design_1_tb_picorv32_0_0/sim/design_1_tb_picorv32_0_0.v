// (c) Copyright 1995-2026 Xilinx, Inc. All rights reserved.
// 
// This file contains confidential and proprietary information
// of Xilinx, Inc. and is protected under U.S. and
// international copyright and other intellectual property
// laws.
// 
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// Xilinx, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) Xilinx shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or Xilinx had been advised of the
// possibility of the same.
// 
// CRITICAL APPLICATIONS
// Xilinx products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of Xilinx products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
// 
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
// 
// DO NOT MODIFY THIS FILE.


// IP VLNV: xilinx.com:module_ref:tb_picorv32:1.0
// IP Revision: 1

`timescale 1ns/1ps

(* IP_DEFINITION_SOURCE = "module_ref" *)
(* DowngradeIPIdentifiedWarnings = "yes" *)
module design_1_tb_picorv32_0_0 (
  clk,
  resetn,
  interconnect_aresetn,
  uart_axi_awaddr,
  uart_axi_awvalid,
  uart_axi_awready,
  uart_axi_wdata,
  uart_axi_wstrb,
  uart_axi_wvalid,
  uart_axi_wready,
  uart_axi_bresp,
  uart_axi_bvalid,
  uart_axi_bready,
  uart_axi_araddr,
  uart_axi_arvalid,
  uart_axi_arready,
  uart_axi_rdata,
  uart_axi_rresp,
  uart_axi_rvalid,
  uart_axi_rready
);

(* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clk, ASSOCIATED_BUSIF uart_axi, ASSOCIATED_RESET resetn, FREQ_HZ 50000000, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1, INSERT_VIP 0" *)
(* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 clk CLK" *)
input wire clk;
(* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME resetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *)
(* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 resetn RST" *)
input wire resetn;
(* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME interconnect_aresetn, POLARITY ACTIVE_LOW, INSERT_VIP 0" *)
(* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 interconnect_aresetn RST" *)
input wire interconnect_aresetn;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 uart_axi AWADDR" *)
output wire [31 : 0] uart_axi_awaddr;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 uart_axi AWVALID" *)
output wire uart_axi_awvalid;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 uart_axi AWREADY" *)
input wire uart_axi_awready;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 uart_axi WDATA" *)
output wire [31 : 0] uart_axi_wdata;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 uart_axi WSTRB" *)
output wire [3 : 0] uart_axi_wstrb;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 uart_axi WVALID" *)
output wire uart_axi_wvalid;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 uart_axi WREADY" *)
input wire uart_axi_wready;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 uart_axi BRESP" *)
input wire [1 : 0] uart_axi_bresp;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 uart_axi BVALID" *)
input wire uart_axi_bvalid;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 uart_axi BREADY" *)
output wire uart_axi_bready;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 uart_axi ARADDR" *)
output wire [31 : 0] uart_axi_araddr;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 uart_axi ARVALID" *)
output wire uart_axi_arvalid;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 uart_axi ARREADY" *)
input wire uart_axi_arready;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 uart_axi RDATA" *)
input wire [31 : 0] uart_axi_rdata;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 uart_axi RRESP" *)
input wire [1 : 0] uart_axi_rresp;
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 uart_axi RVALID" *)
input wire uart_axi_rvalid;
(* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME uart_axi, DATA_WIDTH 32, PROTOCOL AXI4LITE, FREQ_HZ 50000000, ID_WIDTH 0, ADDR_WIDTH 32, AWUSER_WIDTH 0, ARUSER_WIDTH 0, WUSER_WIDTH 0, RUSER_WIDTH 0, BUSER_WIDTH 0, READ_WRITE_MODE READ_WRITE, HAS_BURST 0, HAS_LOCK 0, HAS_PROT 0, HAS_CACHE 0, HAS_QOS 0, HAS_REGION 0, HAS_WSTRB 1, HAS_BRESP 1, HAS_RRESP 1, SUPPORTS_NARROW_BURST 0, NUM_READ_OUTSTANDING 1, NUM_WRITE_OUTSTANDING 1, MAX_BURST_LENGTH 1, PHASE 0.0, CLK_DOMAIN /clk_wiz_0_clk_out1, NUM_READ_THREADS 1, NUM_WRITE_THREADS\
 1, RUSER_BITS_PER_BYTE 0, WUSER_BITS_PER_BYTE 0, INSERT_VIP 0" *)
(* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 uart_axi RREADY" *)
output wire uart_axi_rready;

  tb_picorv32 inst (
    .clk(clk),
    .resetn(resetn),
    .interconnect_aresetn(interconnect_aresetn),
    .uart_axi_awaddr(uart_axi_awaddr),
    .uart_axi_awvalid(uart_axi_awvalid),
    .uart_axi_awready(uart_axi_awready),
    .uart_axi_wdata(uart_axi_wdata),
    .uart_axi_wstrb(uart_axi_wstrb),
    .uart_axi_wvalid(uart_axi_wvalid),
    .uart_axi_wready(uart_axi_wready),
    .uart_axi_bresp(uart_axi_bresp),
    .uart_axi_bvalid(uart_axi_bvalid),
    .uart_axi_bready(uart_axi_bready),
    .uart_axi_araddr(uart_axi_araddr),
    .uart_axi_arvalid(uart_axi_arvalid),
    .uart_axi_arready(uart_axi_arready),
    .uart_axi_rdata(uart_axi_rdata),
    .uart_axi_rresp(uart_axi_rresp),
    .uart_axi_rvalid(uart_axi_rvalid),
    .uart_axi_rready(uart_axi_rready)
  );
endmodule
