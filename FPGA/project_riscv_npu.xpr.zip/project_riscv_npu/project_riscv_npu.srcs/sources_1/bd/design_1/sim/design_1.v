//Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2018.3 (win64) Build 2405991 Thu Dec  6 23:38:27 MST 2018
//Date        : Tue Jul  7 16:02:32 2026
//Host        : 8845HS running 64-bit major release  (build 9200)
//Command     : generate_target design_1.bd
//Design      : design_1
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CORE_GENERATION_INFO = "design_1,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=design_1,x_ipVersion=1.00.a,x_ipLanguage=VERILOG,numBlks=4,numReposBlks=4,numNonXlnxBlks=0,numHierBlks=0,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=1,numPkgbdBlks=0,bdsource=USER,synth_mode=OOC_per_IP}" *) (* HW_HANDOFF = "design_1.hwdef" *) 
module design_1
   (UART_0_rxd,
    UART_0_txd,
    clk,
    resetn);
  (* X_INTERFACE_INFO = "xilinx.com:interface:uart:1.0 UART_0 RxD" *) input UART_0_rxd;
  (* X_INTERFACE_INFO = "xilinx.com:interface:uart:1.0 UART_0 TxD" *) output UART_0_txd;
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK.CLK CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK.CLK, CLK_DOMAIN design_1_clk, FREQ_HZ 50000000, INSERT_VIP 0, PHASE 0.000" *) input clk;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 RST.RESETN RST" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME RST.RESETN, INSERT_VIP 0, POLARITY ACTIVE_LOW" *) input resetn;

  wire axi_uartlite_0_UART_RxD;
  wire axi_uartlite_0_UART_TxD;
  wire clk_in1_0_1;
  wire clk_wiz_0_clk_out1;
  wire clk_wiz_0_locked;
  wire [0:0]proc_sys_reset_0_interconnect_aresetn;
  wire [0:0]proc_sys_reset_0_peripheral_aresetn;
  wire resetn_1;
  wire [31:0]tb_picorv32_0_uart_axi_ARADDR;
  wire tb_picorv32_0_uart_axi_ARREADY;
  wire tb_picorv32_0_uart_axi_ARVALID;
  wire [31:0]tb_picorv32_0_uart_axi_AWADDR;
  wire tb_picorv32_0_uart_axi_AWREADY;
  wire tb_picorv32_0_uart_axi_AWVALID;
  wire tb_picorv32_0_uart_axi_BREADY;
  wire [1:0]tb_picorv32_0_uart_axi_BRESP;
  wire tb_picorv32_0_uart_axi_BVALID;
  wire [31:0]tb_picorv32_0_uart_axi_RDATA;
  wire tb_picorv32_0_uart_axi_RREADY;
  wire [1:0]tb_picorv32_0_uart_axi_RRESP;
  wire tb_picorv32_0_uart_axi_RVALID;
  wire [31:0]tb_picorv32_0_uart_axi_WDATA;
  wire tb_picorv32_0_uart_axi_WREADY;
  wire [3:0]tb_picorv32_0_uart_axi_WSTRB;
  wire tb_picorv32_0_uart_axi_WVALID;

  assign UART_0_txd = axi_uartlite_0_UART_TxD;
  assign axi_uartlite_0_UART_RxD = UART_0_rxd;
  assign clk_in1_0_1 = clk;
  assign resetn_1 = resetn;
  design_1_axi_uartlite_0_0 axi_uartlite_0
       (.rx(axi_uartlite_0_UART_RxD),
        .s_axi_aclk(clk_wiz_0_clk_out1),
        .s_axi_araddr(tb_picorv32_0_uart_axi_ARADDR[3:0]),
        .s_axi_aresetn(proc_sys_reset_0_peripheral_aresetn),
        .s_axi_arready(tb_picorv32_0_uart_axi_ARREADY),
        .s_axi_arvalid(tb_picorv32_0_uart_axi_ARVALID),
        .s_axi_awaddr(tb_picorv32_0_uart_axi_AWADDR[3:0]),
        .s_axi_awready(tb_picorv32_0_uart_axi_AWREADY),
        .s_axi_awvalid(tb_picorv32_0_uart_axi_AWVALID),
        .s_axi_bready(tb_picorv32_0_uart_axi_BREADY),
        .s_axi_bresp(tb_picorv32_0_uart_axi_BRESP),
        .s_axi_bvalid(tb_picorv32_0_uart_axi_BVALID),
        .s_axi_rdata(tb_picorv32_0_uart_axi_RDATA),
        .s_axi_rready(tb_picorv32_0_uart_axi_RREADY),
        .s_axi_rresp(tb_picorv32_0_uart_axi_RRESP),
        .s_axi_rvalid(tb_picorv32_0_uart_axi_RVALID),
        .s_axi_wdata(tb_picorv32_0_uart_axi_WDATA),
        .s_axi_wready(tb_picorv32_0_uart_axi_WREADY),
        .s_axi_wstrb(tb_picorv32_0_uart_axi_WSTRB),
        .s_axi_wvalid(tb_picorv32_0_uart_axi_WVALID),
        .tx(axi_uartlite_0_UART_TxD));
  design_1_clk_wiz_0_0 clk_wiz_0
       (.clk_in1(clk_in1_0_1),
        .clk_out1(clk_wiz_0_clk_out1),
        .locked(clk_wiz_0_locked),
        .resetn(resetn_1));
  design_1_proc_sys_reset_0_0 proc_sys_reset_0
       (.aux_reset_in(1'b1),
        .dcm_locked(clk_wiz_0_locked),
        .ext_reset_in(resetn_1),
        .interconnect_aresetn(proc_sys_reset_0_interconnect_aresetn),
        .mb_debug_sys_rst(1'b0),
        .peripheral_aresetn(proc_sys_reset_0_peripheral_aresetn),
        .slowest_sync_clk(clk_wiz_0_clk_out1));
  design_1_tb_picorv32_0_0 tb_picorv32_0
       (.clk(clk_wiz_0_clk_out1),
        .interconnect_aresetn(proc_sys_reset_0_interconnect_aresetn),
        .resetn(proc_sys_reset_0_peripheral_aresetn),
        .uart_axi_araddr(tb_picorv32_0_uart_axi_ARADDR),
        .uart_axi_arready(tb_picorv32_0_uart_axi_ARREADY),
        .uart_axi_arvalid(tb_picorv32_0_uart_axi_ARVALID),
        .uart_axi_awaddr(tb_picorv32_0_uart_axi_AWADDR),
        .uart_axi_awready(tb_picorv32_0_uart_axi_AWREADY),
        .uart_axi_awvalid(tb_picorv32_0_uart_axi_AWVALID),
        .uart_axi_bready(tb_picorv32_0_uart_axi_BREADY),
        .uart_axi_bresp(tb_picorv32_0_uart_axi_BRESP),
        .uart_axi_bvalid(tb_picorv32_0_uart_axi_BVALID),
        .uart_axi_rdata(tb_picorv32_0_uart_axi_RDATA),
        .uart_axi_rready(tb_picorv32_0_uart_axi_RREADY),
        .uart_axi_rresp(tb_picorv32_0_uart_axi_RRESP),
        .uart_axi_rvalid(tb_picorv32_0_uart_axi_RVALID),
        .uart_axi_wdata(tb_picorv32_0_uart_axi_WDATA),
        .uart_axi_wready(tb_picorv32_0_uart_axi_WREADY),
        .uart_axi_wstrb(tb_picorv32_0_uart_axi_WSTRB),
        .uart_axi_wvalid(tb_picorv32_0_uart_axi_WVALID));
endmodule
