//Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2018.3 (win64) Build 2405991 Thu Dec  6 23:38:27 MST 2018
//Date        : Tue Jul  7 16:02:32 2026
//Host        : 8845HS running 64-bit major release  (build 9200)
//Command     : generate_target design_1_wrapper.bd
//Design      : design_1_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module design_1_wrapper
   (UART_0_rxd,
    UART_0_txd,
    clk,
    resetn);
  input UART_0_rxd;
  output UART_0_txd;
  input clk;
  input resetn;

  wire UART_0_rxd;
  wire UART_0_txd;
  wire clk;
  wire resetn;

  design_1 design_1_i
       (.UART_0_rxd(UART_0_rxd),
        .UART_0_txd(UART_0_txd),
        .clk(clk),
        .resetn(resetn));
endmodule
